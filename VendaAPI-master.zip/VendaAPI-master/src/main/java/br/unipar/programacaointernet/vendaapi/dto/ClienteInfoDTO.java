package br.unipar.programacaointernet.vendaapi.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ClienteInfoDTO {
    private String nomeCliente;
    private String telefoneCliente;
    private String aniversarioCliente;
}
