package br.unipar.programacaointernet.vendaapi.mapper;

import br.unipar.programacaointernet.vendaapi.dto.ClienteQuantidadeVendaDTO;
import br.unipar.programacaointernet.vendaapi.dto.ValorTotalVendaDTO;
import br.unipar.programacaointernet.vendaapi.model.Cliente;
import br.unipar.programacaointernet.vendaapi.model.Venda;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class ValorTotalVendaMapper {

    public static List<ValorTotalVendaDTO> toDTO(List<Venda> vendas, List<Cliente> clientes) {
        List<ValorTotalVendaDTO> lista = new ArrayList<>();

        for (Cliente cliente : clientes) {
            ValorTotalVendaDTO dto = new ValorTotalVendaDTO();
            BigDecimal total = new BigDecimal("0");
            for (Venda venda : vendas) {
                if(venda.getCliente() == cliente) {
                    total = total.add(venda.getTotal());
                }
            }
            dto.setNomeCliente(cliente.getNome());
            dto.setValorTotal(total);

            lista.add(dto);
        }
        return lista;
    }
}
