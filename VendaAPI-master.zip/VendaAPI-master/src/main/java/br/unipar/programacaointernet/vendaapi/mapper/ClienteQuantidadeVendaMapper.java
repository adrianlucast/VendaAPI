package br.unipar.programacaointernet.vendaapi.mapper;

import br.unipar.programacaointernet.vendaapi.dto.ClienteQuantidadeVendaDTO;
import br.unipar.programacaointernet.vendaapi.model.Cliente;

import java.util.List;

public class ClienteQuantidadeVendaMapper {
    public static ClienteQuantidadeVendaDTO toDTO(Cliente cliente, int quantidadeVendas) {
        ClienteQuantidadeVendaDTO dto = new ClienteQuantidadeVendaDTO();
        dto.setNomeCliente(cliente.getNome());
        dto.setQuantidadeVendas(dto.getQuantidadeVendas());
        return dto;
    }
}
