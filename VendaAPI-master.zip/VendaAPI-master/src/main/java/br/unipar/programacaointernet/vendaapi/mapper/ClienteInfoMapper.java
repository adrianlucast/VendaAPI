package br.unipar.programacaointernet.vendaapi.mapper;

import br.unipar.programacaointernet.vendaapi.dto.ClienteInfoDTO;
import br.unipar.programacaointernet.vendaapi.model.Cliente;

public class ClienteInfoMapper {
    public static ClienteInfoDTO toDTO(Cliente cliente) {
        ClienteInfoDTO dto = new ClienteInfoDTO();
        dto.setNomeCliente(cliente.getNome());
        dto.setTelefoneCliente(cliente.getTelefone());
        dto.setAniversarioCliente(cliente.getAniversario());
        return dto;
    }
}
